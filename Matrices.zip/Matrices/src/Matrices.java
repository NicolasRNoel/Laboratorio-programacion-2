import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Matrices extends JFrame {
    private JTextField txtCedula, txtNombre, txtEstatura, txtEdad;
    private JTextArea txtResultado;
    private ArrayList<Persona> personas;

    public Matrices() {

        setTitle("Gestión de Personas");
        setSize(700, 500);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(new BorderLayout(15, 15));
        getContentPane().setBackground(new Color(245, 245, 245));
        personas = new ArrayList<>();


        JLabel titulo = new JLabel("Registro y Ordenamiento de Personas", SwingConstants.CENTER);
        titulo.setFont(new Font("Segoe UI", Font.BOLD, 22));
        titulo.setForeground(new Color(30, 60, 114));
        add(titulo, BorderLayout.NORTH);

        JPanel panelCentro = new JPanel(new GridBagLayout());
        panelCentro.setBackground(new Color(255, 255, 255));
        panelCentro.setBorder(BorderFactory.createEmptyBorder(15, 15, 15, 15));
        GridBagConstraints gbc = new GridBagConstraints();
        gbc.insets = new Insets(10, 10, 10, 10);
        gbc.fill = GridBagConstraints.HORIZONTAL;

        JLabel lblCedula = new JLabel("Cédula:");
        JLabel lblNombre = new JLabel("Nombre:");
        JLabel lblEstatura = new JLabel("Estatura (m):");
        JLabel lblEdad = new JLabel("Edad:");

        lblCedula.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblNombre.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEstatura.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        lblEdad.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        txtCedula = new JTextField();
        txtNombre = new JTextField();
        txtEstatura = new JTextField();
        txtEdad = new JTextField();

        gbc.gridx = 0; gbc.gridy = 0; panelCentro.add(lblCedula, gbc);
        gbc.gridx = 1; panelCentro.add(txtCedula, gbc);

        gbc.gridx = 0; gbc.gridy = 1; panelCentro.add(lblNombre, gbc);
        gbc.gridx = 1; panelCentro.add(txtNombre, gbc);

        gbc.gridx = 0; gbc.gridy = 2; panelCentro.add(lblEstatura, gbc);
        gbc.gridx = 1; panelCentro.add(txtEstatura, gbc);

        gbc.gridx = 0; gbc.gridy = 3; panelCentro.add(lblEdad, gbc);
        gbc.gridx = 1; panelCentro.add(txtEdad, gbc);

        JButton btnAgregar = new JButton("➕ Agregar Persona");
        btnAgregar.setBackground(new Color(30, 144, 255));
        btnAgregar.setForeground(Color.WHITE);
        btnAgregar.setFocusPainted(false);
        btnAgregar.setFont(new Font("Segoe UI", Font.BOLD, 14));
        btnAgregar.setBorder(BorderFactory.createEmptyBorder(8, 15, 8, 15));

        gbc.gridx = 0; gbc.gridy = 4; gbc.gridwidth = 2;
        panelCentro.add(btnAgregar, gbc);

        add(panelCentro, BorderLayout.WEST);

        txtResultado = new JTextArea();
        txtResultado.setEditable(false);
        txtResultado.setFont(new Font("Consolas", Font.PLAIN, 13));
        txtResultado.setBackground(new Color(250, 250, 250));
        txtResultado.setBorder(BorderFactory.createLineBorder(new Color(200, 200, 200)));
        JScrollPane scroll = new JScrollPane(txtResultado);
        scroll.setBorder(BorderFactory.createTitledBorder("📋 Lista de Personas"));
        add(scroll, BorderLayout.CENTER);

        JPanel panelOrden = new JPanel();
        panelOrden.setBackground(new Color(230, 240, 250));
        panelOrden.setBorder(BorderFactory.createEmptyBorder(10, 10, 10, 10));

        String[] criterios = {"Edad", "Estatura"};
        JComboBox<String> comboCriterio = new JComboBox<>(criterios);
        comboCriterio.setFont(new Font("Segoe UI", Font.PLAIN, 14));

        JButton btnBurbuja = new JButton("Ordenar con Burbuja");
        btnBurbuja.setBackground(new Color(46, 204, 113));
        btnBurbuja.setForeground(Color.WHITE);
        btnBurbuja.setFont(new Font("Segoe UI", Font.BOLD, 13));

        JButton btnMerge = new JButton("Ordenar con MergeSort");
        btnMerge.setBackground(new Color(155, 89, 182));
        btnMerge.setForeground(Color.WHITE);
        btnMerge.setFont(new Font("Segoe UI", Font.BOLD, 13));

        panelOrden.add(new JLabel("Ordenar por: "));
        panelOrden.add(comboCriterio);
        panelOrden.add(btnBurbuja);
        panelOrden.add(btnMerge);

        add(panelOrden, BorderLayout.SOUTH);

        btnAgregar.addActionListener(e -> {
            try {
                Persona p = new Persona(
                        txtCedula.getText(),
                        txtNombre.getText(),
                        Double.parseDouble(txtEstatura.getText()),
                        Integer.parseInt(txtEdad.getText())
                );
                personas.add(p);
                txtResultado.append("✅ Agregado: " + p + "\n");
                txtCedula.setText(""); txtNombre.setText("");
                txtEstatura.setText(""); txtEdad.setText("");
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(this, "❌ Datos inválidos. Verifica los campos.");
            }
        });

        btnBurbuja.addActionListener(e -> {
            Ordenamientos.burbuja(personas, comboCriterio.getSelectedItem().toString());
            mostrarLista();
        });

        btnMerge.addActionListener(e -> {
            Ordenamientos.mergeSort(personas, comboCriterio.getSelectedItem().toString());
            mostrarLista();
        });
    }

    private void mostrarLista() {
        txtResultado.setText("");
        for (Persona p : personas) {
            txtResultado.append(p.toString() + "\n");
        }
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> {
            Matrices gui = new Matrices();
            gui.setVisible(true);
            gui.setLocationRelativeTo(null);
        });
    }
}
