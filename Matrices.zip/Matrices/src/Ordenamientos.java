import java.util.ArrayList;

public class Ordenamientos {

    public static void burbuja(ArrayList<Persona> lista, String criterio) {
        int n = lista.size();
        for (int i = 0; i < n-1; i++) {
            for (int j = 0; j < n-i-1; j++) {
                if (comparar(lista.get(j), lista.get(j+1), criterio) < 0) {
                    Persona temp = lista.get(j);
                    lista.set(j, lista.get(j+1));
                    lista.set(j+1, temp);
                }
            }
        }
    }

    public static void mergeSort(ArrayList<Persona> lista, String criterio) {
        if (lista.size() > 1) {
            int mid = lista.size() / 2;
            ArrayList<Persona> left = new ArrayList<>(lista.subList(0, mid));
            ArrayList<Persona> right = new ArrayList<>(lista.subList(mid, lista.size()));

            mergeSort(left, criterio);
            mergeSort(right, criterio);

            merge(lista, left, right, criterio);
        }
    }

    private static void merge(ArrayList<Persona> lista, ArrayList<Persona> left, ArrayList<Persona> right, String criterio) {
        int i = 0, j = 0, k = 0;
        while (i < left.size() && j < right.size()) {
            if (comparar(left.get(i), right.get(j), criterio) >= 0) {
                lista.set(k++, left.get(i++));
            } else {
                lista.set(k++, right.get(j++));
            }
        }
        while (i < left.size()) lista.set(k++, left.get(i++));
        while (j < right.size()) lista.set(k++, right.get(j++));
    }

    private static int comparar(Persona p1, Persona p2, String criterio) {
        switch (criterio) {
            case "Edad":
                return Integer.compare(p1.getEdad(), p2.getEdad());
            case "Estatura":
                return Double.compare(p1.getEstatura(), p2.getEstatura());
            default: return 0;
        }
    }
}
