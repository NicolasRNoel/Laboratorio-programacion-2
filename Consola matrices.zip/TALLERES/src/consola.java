import java.util.*;

public class consola {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {
        int opcion;
        do {
            System.out.println("\n MENÚ PRINCIPAL ");
            System.out.println("1. Operaciones con matrices");
            System.out.println("2. Algoritmos de ordenamiento");
            System.out.println("3. Salir");
            System.out.print("Seleccione una opción: ");
            opcion = sc.nextInt();

            switch (opcion) {
                case 1 -> menuMatrices();
                case 2 -> menuOrdenamientos();
                case 3 -> System.out.println("Saliendo...");
                default -> System.out.println("error");
            }
        } while (opcion != 3);
    }
    static void menuMatrices() {
        System.out.println("\n--- Operaciones con Matrices ---");
        System.out.println("1. Suma de matrices");
        System.out.println("2. Producto de matrices");
        System.out.println("3. Inversa de matriz");
        System.out.println("4. Producto matriz por vector");
        System.out.print("Seleccione: ");
        int opcion = sc.nextInt();

        switch (opcion) {
            case 1 -> sumaMatrices();
            case 2 -> productoMatrices();
            case 3 -> inversaMatriz();
            case 4 -> productoMatrizVector();
            default -> System.out.println("error");
        }
    }
    static void sumaMatrices() {
        System.out.print("Ingrese filas: ");
        int f = sc.nextInt();
        System.out.print("Ingrese columnas: ");
        int c = sc.nextInt();

        double[][] A = leerMatriz(f, c, "A");
        double[][] B = leerMatriz(f, c, "B");
        double[][] C = new double[f][c];

        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                C[i][j] = A[i][j] + B[i][j];
            }
        }
        System.out.println("Resultado:");
        imprimirMatriz(C);
    }
    static void productoMatrices() {
        System.out.print("Ingrese filas de A: ");
        int f1 = sc.nextInt();
        System.out.print("Ingrese columnas de A / filas de B: ");
        int c1 = sc.nextInt();
        System.out.print("Ingrese columnas de B: ");
        int c2 = sc.nextInt();

        double[][] A = leerMatriz(f1, c1, "A");
        double[][] B = leerMatriz(c1, c2, "B");

        double[][] C = new double[f1][c2];

        for (int i = 0; i < f1; i++) {
            for (int j = 0; j < c2; j++) {
                for (int k = 0; k < c1; k++) {
                    C[i][j] += A[i][k] * B[k][j];
                }
            }
        }

        System.out.println("Resultado:");
        imprimirMatriz(C);
    }
    static void inversaMatriz() {
        System.out.print("Ingrese tamaño de la matriz cuadrada: ");
        int n = sc.nextInt();
        double[][] A = leerMatriz(n, n, "A");

        double[][] I = new double[n][n];
        for (int i = 0; i < n; i++) I[i][i] = 1;

        for (int i = 0; i < n; i++) {
            double pivote = A[i][i];
            if (pivote == 0) {
                System.out.println("error");
                return;
            }
            for (int j = 0; j < n; j++) {
                A[i][j] /= pivote;
                I[i][j] /= pivote;
            }
            for (int k = 0; k < n; k++) {
                if (k != i) {
                    double factor = A[k][i];
                    for (int j = 0; j < n; j++) {
                        A[k][j] -= factor * A[i][j];
                        I[k][j] -= factor * I[i][j];
                    }
                }
            }
        }

        System.out.println("Inversa:");
        imprimirMatriz(I);
    }
    static void productoMatrizVector() {
        System.out.print("Ingrese filas de la matriz: ");
        int f = sc.nextInt();
        System.out.print("Ingrese columnas de la matriz: ");
        int c = sc.nextInt();

        double[][] A = leerMatriz(f, c, "A");

        double[] v = new double[c];
        System.out.println("Ingrese vector (" + c + " elementos):");
        for (int i = 0; i < c; i++) v[i] = sc.nextDouble();

        double[] resultado = new double[f];
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                resultado[i] += A[i][j] * v[j];
            }
        }
        System.out.println("Resultado:");
        System.out.println(Arrays.toString(resultado));
    }
    static double[][] leerMatriz(int f, int c, String nombre) {
        double[][] M = new double[f][c];
        System.out.println("Ingrese valores de matriz " + nombre + ":");
        for (int i = 0; i < f; i++) {
            for (int j = 0; j < c; j++) {
                M[i][j] = sc.nextDouble();
            }
        }
        return M;
    }

    static void imprimirMatriz(double[][] M) {
        for (double[] fila : M) {
            System.out.println(Arrays.toString(fila));
        }
    }
    static void menuOrdenamientos() {
        System.out.print("Ingrese tamaño del arreglo: ");
        int n = sc.nextInt();
        double[] arr = new double[n];
        Random rand = new Random();

        for (int i = 0; i < n; i++) arr[i] = rand.nextDouble() * 100;

        System.out.println("1. Burbuja\n2. Inserción\n3. Selección\n4. MergeSort");
        System.out.print("Seleccione: ");
        int opcion = sc.nextInt();

        double[] copia = Arrays.copyOf(arr, arr.length);
        long start = System.nanoTime();

        switch (opcion) {
            case 1 -> burbuja(copia);
            case 2 -> insercion(copia);
            case 3 -> seleccion(copia);
            case 4 -> mergeSort(copia, 0, copia.length - 1);
            default -> {
                System.out.println("error");
                return;
            }
        }

        long end = System.nanoTime();
        System.out.println("Ordenado: " + Arrays.toString(copia));
        System.out.println("Tiempo (ns): " + (end - start));
    }
    static void burbuja(double[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            for (int j = 0; j < arr.length - i - 1; j++) {
                if (arr[j] > arr[j + 1]) {
                    double temp = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = temp;
                }
            }
        }
    }

    static void insercion(double[] arr) {
        for (int i = 1; i < arr.length; i++) {
            double key = arr[i];
            int j = i - 1;
            while (j >= 0 && arr[j] > key) {
                arr[j + 1] = arr[j];
                j--;
            }
            arr[j + 1] = key;
        }
    }

    static void seleccion(double[] arr) {
        for (int i = 0; i < arr.length - 1; i++) {
            int min = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j] < arr[min]) min = j;
            }
            double temp = arr[min];
            arr[min] = arr[i];
            arr[i] = temp;
        }
    }
    static void mergeSort(double[] arr, int l, int r) {
        if (l < r) {
            int m = (l + r) / 2;
            mergeSort(arr, l, m);
            mergeSort(arr, m + 1, r);
            merge(arr, l, m, r);
        }
    }
    static void merge(double[] arr, int l, int m, int r) {
        int n1 = m - l + 1, n2 = r - m;
        double[] L = new double[n1];
        double[] R = new double[n2];
        System.arraycopy(arr, l, L, 0, n1);
        System.arraycopy(arr, m + 1, R, 0, n2);
        int i = 0, j = 0, k = l;
        while (i < n1 && j < n2) {
            if (L[i] <= R[j]) arr[k++] = L[i++];
            else arr[k++] = R[j++];
        }
        while (i < n1) arr[k++] = L[i++];
        while (j < n2) arr[k++] = R[j++];
    }
}